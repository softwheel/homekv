pub mod error;

pub use error::{Error, Result};